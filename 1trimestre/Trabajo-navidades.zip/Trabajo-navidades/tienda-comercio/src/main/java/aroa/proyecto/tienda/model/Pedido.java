package aroa.proyecto.tienda.model;

public class Pedido {
    private int idPedido;
    private int idUsuario;
    private int idProducto;

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdUsuario() {
        return idUsuario;}

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;

    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }




}
