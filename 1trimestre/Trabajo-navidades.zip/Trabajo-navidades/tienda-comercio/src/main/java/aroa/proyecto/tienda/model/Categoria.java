package aroa.proyecto.tienda.model;

public class Categoria {
    private int idCategoria;
    private String nameCategoria;

    public int getIdCategoria() {
        return idCategoria;
    }

    private void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNameCategoria() {
        return nameCategoria;
    }

    private void setNameCategoria(String nameCategoria) {
        this.nameCategoria = nameCategoria;
    }

}
