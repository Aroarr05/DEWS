package aroa.proyecto.tienda.filter;

public class CategoriaFilter {
}
