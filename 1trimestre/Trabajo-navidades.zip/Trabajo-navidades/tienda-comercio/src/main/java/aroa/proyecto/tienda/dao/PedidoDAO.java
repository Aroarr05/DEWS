package aroa.proyecto.tienda.dao;

import aroa.proyecto.tienda.model.Pedido;

public interface PedidoDAO {


}
