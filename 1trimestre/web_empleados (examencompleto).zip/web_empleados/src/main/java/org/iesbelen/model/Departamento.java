package org.iesbelen.model;

public class Departamento {
    private int codigo;
    private String nombre;
    private Double presupuesto;
    private Double gastos;

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public Double getPresupuesto() {
        return presupuesto;
    }
    public void setPresupuesto(Double presupuesto) {
        this.presupuesto = presupuesto;
    }
    public Double getGastos() {
        return gastos;
    }
    public void setGastos(Double gastos) {
        this.gastos = gastos;
    }
}
